#include<iostream>
#include <vector>
#include <typeinfo>
#include <sstream>
#include "btree.h"
using namespace std;

enum types {type_int, type_float, type_double, type_bool, type_pchar};

/*
void example_read(){
    string url = "/Users/acruzch/Desktop/proyecto_db/demo.csv";
    vector<vector<string>> content;
    vector<string> row;
    string line, word;
    fstream file;
    file.open(url);
    if(file.is_open()){
        while(getline(file, line)){
            row.clear();
            stringstream str(line);
            while(getline(str, word, ',')){
                row.push_back(word);
                cout<<word<<endl;
            }
            content.push_back(row);
        }
    }
    cout<<"Could not open the file\n";
    cout<<content.size()<<endl;
    for(int i=0;i<content.size();i++){
        for(int j=0;j<content[i].size();j++){
            cout<<content[i][j]<<" ";
        }
    cout<<"\n";
    }
    file.close();
}

void example_btree_run(){
    btree ejm();
    
    ejm.insertion(8);
    ejm.insertion(4);
    ejm.insertion(9);
    ejm.insertion(3);
    ejm.insertion(6);
    
    cout<<endl;
    
    ejm.traverse();
    
    vector<inode*>lista1;
    
    inode* dato1 = new inode;
    dato1->type = type_int;
    int aux = 22;
    dato1->vp = &aux;
    lista1.push_back(dato1);
    
    inode* dato2 = new inode;
    dato2->type = type_pchar;
    char aux2[12] = "hola mundo";
    dato2->vp = &aux2;
    lista1.push_back(dato2);
    
    
    for (int i=0; i<lista1.size(); i++) {
        if(lista1[i]->type==type_int){
            cout<<*(int*)lista1[i]->vp<<endl;
        }
        else if (lista1[i]->type==type_bool){
            cout<<*(bool*)lista1[i]->vp<<endl;
        }
        else if (lista1[i]->type==type_pchar){
            cout<<(char*)lista1[i]->vp<<endl;
        }
    }

}
 */

struct inode{
    types type;
    void* vp;
};


int main(int argc, const char * argv[]) {

    string url = "/Users/acruzch/Desktop/proyecto_db/demo.csv";

       
    btree demo2;
    btree demo3;
    btree demo4;
    btree demo5;
    btree demo6;
    
    demo2.read_file(url);
    demo2.traverse();
    demo2.get_info_btree();
     
     
    /*
    vector<inode*>lista1;
    inode* dato1 = new inode;
    dato1->type = type_int;
    int aux = 22;
    dato1->vp = &aux;
    lista1.push_back(dato1);
    
    inode* dato2 = new inode;
    dato2->type = type_pchar;
    char aux2[12] = "hola mundo";
    dato2->vp = &aux2;
    lista1.push_back(dato2);
    
    
    for (int i=0; i<lista1.size(); i++) {
        if(lista1[i]->type==type_int){
            cout<<*(int*)lista1[i]->vp<<endl;
        }
        else if (lista1[i]->type==type_bool){
            cout<<*(bool*)lista1[i]->vp<<endl;
        }
        else if (lista1[i]->type==type_pchar){
            cout<<(char*)lista1[i]->vp<<endl;
        }
    }
     
     */
    
    
    
    
    
    return (0);
}
