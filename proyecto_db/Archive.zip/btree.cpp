#include "btree.h"

btree::btree() {
    this->root = nullptr;
    this->t = 2;
}

void btree::traverse() {
    if (root != nullptr) {
        root->traverse();
    }
}

// Insertion operation
void btree::insertion(int k) {
    if (root == nullptr) {
        root = new bnode(t, true);
        root->keys.first[0] = k;
        root->n = 1;
    }else{
        if (root->n == 2 * t - 1) {
            bnode *s = new bnode(t, false);
            s->C[0] = root;
            s->splitChild(0, root);
            int i = 0;
            if (s->keys.first[0] < k) {
                i++;
            }
            s->C[i]->insertNonFull(k);
            root = s;
        }else {
            root->insertNonFull(k);
        }
    }
}

// Delete Operation
void btree::deletion(int k) {
    if (!root) {
        cout << "The tree is empty\n";
        return;
    }
    root->deletion(k);
    if (root->n == 0) {
        bnode *tmp = root;
        if (root->leaf) {
            root = nullptr;
        }else {
            root = root->C[0];
        }
        delete tmp;
    }
    return;
}

void btree::get_info_btree(){
    cout<<"Root: "<<*(this->root->keys.first)<<endl;
}

void btree::read_file(string url){
    int count=0;
    cout<<"Read data"<<endl;
    ifstream myFile;
    myFile.open(url);
    string line, word;
    getline(myFile,line);
    stringstream str(line);
    while (getline(str,word,',')) {
        cout<<word<<endl;
    }
    while (getline(myFile,line)) {
        stringstream str(line);
        while (getline(str,word,',')) {
            cout<<word<<endl;
        }
        this->insertion(++count);
    }
    cout<<"count: "<<count<<endl;
    myFile.close();
}




