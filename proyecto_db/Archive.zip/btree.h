#ifndef PROYECTOBD2_BTREE_H
#define PROYECTOBD2_BTREE_H
#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "bnode.h"
using namespace::std;


class btree {
    int t;
    bnode *root;
public:
    btree();
    void traverse();
    void insertion(int k);
    void deletion(int k);
    void get_info_btree();
    void read_file(string);
};

#endif //PROYECTOBD2_BTREE_H
