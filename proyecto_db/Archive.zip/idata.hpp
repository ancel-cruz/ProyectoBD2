#ifndef idata_hpp
#define idata_hpp

#include <iostream>
#include <vector>
using namespace::std;

struct idata{
    vector<void*>data;
};

#endif /* idata_hpp */
